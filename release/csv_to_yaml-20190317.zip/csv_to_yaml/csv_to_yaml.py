# -*- coding: utf-8 -*-

import os
import sys
SCRIPT_NAME = os.path.basename(sys.argv[0])
import logging
import csv
from collections import OrderedDict

# https://stackoverflow.com/questions/11927278/how-to-configure-logging-in-python
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s  %(levelname)s:%(name)s  %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
    filename=SCRIPT_NAME+'.log',
    filemode='w')

#
# ARGUMENTS
# -----------------

args_list = sys.argv[1:]
print('debug: args_list = {}'.format(args_list))


ARG_NAMES = ['csv_file', 'yaml_file']
NB_ARGS = len(ARG_NAMES)
USAGE_STRING = \
"""
Usage: {} {}
""".format(SCRIPT_NAME, ' '.join(ARG_NAMES))

# Testing number of arguments
if len(args_list) != NB_ARGS:
    print(USAGE_STRING)
    exit()

# Tesing existence of input file
csv_filepath = args_list[0]
yaml_filepath = args_list[1]
if not os.path.exists(csv_filepath):
    print("ERROR: CSV file '{}' does not exists".format(csv_filepath))
    print(USAGE_STRING)
    exit()

#
# VARIABLES
# -----------------

CSV_DELIMITER = ';'

#
# FUNCTIONS
# -----------------

def pretty_print_dict(d, indent=0):
   for key, value in d.items():
      print('\t' * indent + str(key))
      if isinstance(value, dict):
         pretty_print_dict(value, indent+1)
      else:
         print('\t' * (indent+1) + str(value))

def add_entry_to_dict(entry_value, input_dict, keys_path):
    logging.debug('CALL:add_entry_to_dict({}, {}, {})'.format(entry_value, input_dict, keys_path))

    if len(keys_path) == 0:
        raise Exception('Empty keys path')
    
    current_dict = input_dict

    head, tail = keys_path[0], keys_path[1:]
    current_key = head
    remaining_keys = tail
    logging.debug('\tcurrent_key = {}'.format(current_key))
    logging.debug('\tremaining_keys = {}'.format(remaining_keys))

    if len(keys_path) == 1:
        input_dict[current_key] = entry_value
        return input_dict
    else:
        if current_key not in current_dict:
            logging.debug('\tkey "{}" not in dict {}'.format(current_key, current_dict))
            current_dict[current_key] = add_entry_to_dict(entry_value, OrderedDict(), remaining_keys)
        else:
            current_dict[current_key] = add_entry_to_dict(entry_value, current_dict[current_key], remaining_keys)
        return current_dict

def partition_row_dicts_by_first_key(row_dicts):
    logging.debug('CALL:split_row_dicts_by_first_key(row_dicts)')

    partitions = OrderedDict()

    for rd in row_dicts:
        key_1 = rd.keys()[0]
        key_2 = rd[key_1].keys()[0]
        logging.debug('\tkey_1 = {}'.format(key_1))
        logging.debug('\tkey_2 = {}'.format(key_2))

        partition_name = rd[key_1][key_2]

        if partition_name not in partitions:
            logging.debug('\tkey "{}" not in dict {}'.format(partition_name, rd))
            partitions[partition_name] = [rd]
        else:
            partitions[partition_name].append(rd)

    return partitions

def extract_first_key_with_number_sign(keys_list):
    result = None
    for k in keys_list:
        if '#' in k:
            result = k
            break
    return result

def aggregate_second_level_list(row_dicts):
    logging.debug('CALL:aggregate_second_level_list(row_dicts)')

    aggregate_list = []

    rd_0 = row_dicts[0]
    key_1 = rd_0.keys()[0]
    key_2 = extract_first_key_with_number_sign(rd_0[key_1].keys())
    logging.debug('\tkey_1 = {}'.format(key_1))
    logging.debug('\tkey_2 = {}'.format(key_2))

    for rd in row_dicts:
        list_element = rd[key_1][key_2]
        logging.debug('\tlist_element = {}'.format(list_element))
        aggregate_list.append(list_element)

    result = row_dicts[0]
    result[key_1][key_2] = aggregate_list
    
    return result

def aggregate_first_level_list(row_dicts):
    logging.debug('CALL:aggregate_first_level_list(row_dicts)')

    aggregate_list = []

    rd_0 = row_dicts[0]
    logging.debug('\rd_0 = {}'.format(rd_0))
    key_1 = extract_first_key_with_number_sign(rd_0.keys())
    logging.debug('\tkey_1 = {}'.format(key_1))

    for rd in row_dicts:
        list_element = rd[key_1]
        logging.debug('\tlist_element = {}'.format(list_element))
        aggregate_list.append(list_element)

    result = row_dicts[0]
    result[key_1] = aggregate_list
    
    return result

def generate_yaml(input_object, depth=0, parent_key=''):
    logging.debug('CALL:generate_yaml(input_object)')
    not_root = depth != 0

    two_spaces = ' '
    inside_list = '#' in parent_key

    input_type = type(input_object)
    spaces = two_spaces * depth 
    new_line = '\n'
    result_string = ''

    # dict
    if input_type is OrderedDict:

        if inside_list:
            result_string += new_line

        elem_counter = 0
        for key in input_object:
            elem_counter += 1
            if elem_counter == 1:
                prefix = ' ' * (depth - 2) + '- ' if not_root else ''
                result_string += prefix + '{}: {}'.format(
                    key.replace('#', ''),
                    generate_yaml(input_object[key], depth + 1, key)
                ) + new_line
            else:
                result_string += spaces + '{}: {}'.format(
                    key.replace('#', ''),
                    generate_yaml(input_object[key], depth + 1, key)
                ) + new_line

    # list
    elif input_type is list:
        elem_counter = 0

        for elem in input_object:
            elem_counter += 1
            if elem_counter == 1:
                result_string += spaces + '{}'.format(
                    generate_yaml(elem, depth + 1, parent_key)
                )
            else:
                result_string += spaces + '{}'.format(
                    generate_yaml(elem, depth + 1, parent_key)
                )

    else:
        result_string += '"{}"'.format(input_object)

    # Trimming
    result_string = result_string.rstrip()
    logging.debug('\tresult_string = {}'.format(result_string))
    return result_string

#
# MAIN
# -----------------

# Loading of CSV file
csv_headers = []
csv_rows = []
with open(csv_filepath) as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=CSV_DELIMITER)
    line_count = 0
    for row in csv_reader:
        csv_rows.append(row)
        # vvv DEUBG vvv
        if line_count == 0:
            csv_headers = row
            logging.info('HEADERS = [ {} ]'.format(" | ".join(row)))
            line_count += 1
        else:
            logging.info(('ROW_{} = [ {} ]'.format(line_count, " | ".join(row))))
            line_count += 1
    logging.info('Processed {} lines.'.format(line_count))

# Conversion of CSV to YAML
row_dicts = []
row_count = 0
for row in csv_rows[1:]:
    row_count += 1
    
    row_dict = OrderedDict()
    
    for colname in csv_headers:

        # 1. Split colname
        colname_split = colname.split("/")

        # 2. Add keys
        for fieldname in colname_split:
            row_dict = add_entry_to_dict(
                row[csv_headers.index(colname)],
                row_dict,
                colname_split)
            # logging.debug('>>> row_dict = {}'.format(row_dict))
    # print('ROW_{}'.format(row_count)) # PRINT
    # pretty_print_dict(row_dict) # PRINT
            # exit
    row_dicts.append(row_dict)

rd_parts = partition_row_dicts_by_first_key(row_dicts)

# aggregate_second_level_list
row_dicts_aggregated = []
for key in rd_parts.keys():
    logging.debug("rd_parts[{}] = {}".format(key, rd_parts[key]))
    row_dicts_aggregated.append(aggregate_second_level_list(rd_parts[key]))

for elem in row_dicts_aggregated:
    key_1 = elem.keys()[0]
    key_2 = elem[key_1].keys()[0]
    logging.debug("elem[{}] = {}".format(elem[key_1][key_2], elem))

# aggregate_first_level_list
final_dict = aggregate_first_level_list(row_dicts_aggregated)

logging.debug("\n\trow_dicts_aggregated_final = {}".format(final_dict))

# pretty_print_dict(final_dict) # DEBUG

# Generating YAML string
yaml_string = generate_yaml(final_dict)
# print(yaml_string) # PRINT

# Writing YAML string to output file
with open(yaml_filepath, "w") as text_file:
    text_file.write(yaml_string)
